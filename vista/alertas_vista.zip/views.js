/* views.js - capa Vistas final
   - Login demo
   - Dashboard with Leaflet map, Chart.js chart
   - Registro with mini-map to pick coords
   - Historial with actions
   - Usuarios CRUD
   - Dark mode toggle
*/

function nowISO(){ return new Date().toISOString(); }
function loadAlerts(){ return JSON.parse(localStorage.getItem('alerts_v2')||'[]'); }
function saveAlerts(a){ localStorage.setItem('alerts_v2', JSON.stringify(a)); }
function loadUsers(){ return JSON.parse(localStorage.getItem('users_v2')||'[]'); }
function saveUsers(u){ localStorage.setItem('users_v2', JSON.stringify(u)); }

document.addEventListener('DOMContentLoaded', ()=> {
  // preload demo
  if(!localStorage.getItem('users_v2')) {
    saveUsers([{name:'admin',role:'autoridad',created:nowISO()}]);
  }
  if(!localStorage.getItem('alerts_v2')){
    saveAlerts([
      {id:'a1',tipo:'Inundación',ubicacion:'Río Junín',coords:'-11.77,-75.33',descripcion:'Aumento de caudal',fecha:nowISO(),estado:'activa'},
      {id:'a2',tipo:'Derrumbe',ubicacion:'Carretera X',coords:'-11.65,-75.25',descripcion:'Pequeño deslizamiento',fecha:nowISO(),estado:'confirmada'}
    ]);
  }

  // login
  const btnLogin = document.getElementById('btnLogin');
  if(btnLogin){
    btnLogin.addEventListener('click', ()=> {
      const u = document.getElementById('usuario').value.trim();
      const p = document.getElementById('clave').value.trim();
      if(u==='admin' && p==='1234'){ localStorage.setItem('session_user', JSON.stringify({name:'admin',role:'autoridad'})); window.location='dashboard.html'; }
      else document.getElementById('mensaje').textContent='Credenciales inválidas';
    });
  }

  // common: user display and logout
  const session = JSON.parse(localStorage.getItem('session_user')||'null');
  const userEl = document.getElementById('usuarioNombre');
  if(userEl) userEl.textContent = session ? session.name + ' ('+session.role+')' : 'Invitado';

  const logout = document.getElementById('logoutBtn');
  if(logout) logout.addEventListener('click', ()=> { localStorage.removeItem('session_user'); window.location='index.html'; });

  // theme toggle
  const themeToggle = document.getElementById('themeToggle');
  if(themeToggle){
    const current = localStorage.getItem('theme')||'light';
    if(current==='dark') document.documentElement.setAttribute('data-theme','dark');
    themeToggle.addEventListener('click', ()=> {
      const t = document.documentElement.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
      if(t==='dark') document.documentElement.setAttribute('data-theme','dark'); else document.documentElement.removeAttribute('data-theme');
      localStorage.setItem('theme', t);
    });
  }

  // Dashboard specifics
  if(document.getElementById('totalAlertas')){
    const alerts = loadAlerts();
    document.getElementById('totalAlertas').textContent = alerts.length;
    document.getElementById('alertasActivas').textContent = alerts.filter(a=>a.estado==='activa').length;
    document.getElementById('usuariosCount').textContent = loadUsers().length;
    const rec = document.getElementById('recientes');
    rec.innerHTML = '';
    alerts.slice().reverse().slice(0,6).forEach(a=>{
      const li = document.createElement('li');
      li.textContent = a.tipo + ' - ' + a.ubicacion + ' ('+ new Date(a.fecha).toLocaleString()+')';
      rec.appendChild(li);
    });

    // Map quick
    const mapEl = document.getElementById('map');
    if(mapEl){
      const map = L.map('map').setView([-11.77,-75.33], 8);
      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{attribution:'© OpenStreetMap contributors'}).addTo(map);
      alerts.forEach(a=>{
        if(!a.coords) return;
        const [lat,lng] = a.coords.split(',').map(Number);
        if(isNaN(lat)) return;
        const color = a.estado==='activa' ? '#dc2626' : '#16a34a';
        const icon = L.divIcon({html:'<div style="background:'+color+';color:white;padding:6px;border-radius:6px;font-weight:700">'+a.tipo[0]+'</div>', className:''});
        L.marker([lat,lng],{icon}).addTo(map).bindPopup('<b>'+a.tipo+'</b><br>'+a.ubicacion);
      });
    }

    // Chart - dynamic counts by type
    const chartEl = document.getElementById('chartTipos');
    if(chartEl){
      const counts = {};
      alerts.forEach(a=> counts[a.tipo] = (counts[a.tipo]||0)+1 );
      const labels = Object.keys(counts);
      const data = Object.values(counts);
      new Chart(chartEl,{type:'doughnut',data:{labels, datasets:[{data, backgroundColor:['#2563eb','#dc2626','#f59e0b','#16a34a']}]}, options:{responsive:true}});
    }
  }

  // Registro page
  if(document.getElementById('miniMap')){
    const mini = L.map('miniMap').setView([-11.77,-75.33], 8);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{attribution:'© OpenStreetMap contributors'}).addTo(mini);
    let marker = null;
    mini.on('click', e=> {
      const {lat,lng} = e.latlng;
      if(marker) marker.setLatLng([lat,lng]); else marker = L.marker([lat,lng]).addTo(mini);
      document.getElementById('coords').value = lat.toFixed(6)+','+lng.toFixed(6);
    });
    document.getElementById('btnGuardar')?.addEventListener('click', ()=>{
      const tipo = document.getElementById('tipo').value;
      const ubicacion = document.getElementById('ubicacion').value.trim();
      const descripcion = document.getElementById('descripcion').value.trim();
      const coords = document.getElementById('coords').value;
      if(!tipo || !ubicacion){ document.getElementById('msgRegistro').textContent = 'Complete tipo y ubicación'; return; }
      const alerts = loadAlerts();
      alerts.push({id:'a'+Date.now(), tipo, ubicacion, descripcion, coords, fecha: nowISO(), estado:'activa'});
      saveAlerts(alerts);
      document.getElementById('msgRegistro').textContent = 'Alerta registrada';
      setTimeout(()=> location.href='dashboard.html',800);
    });
  }

  // Mapa page
  if(document.getElementById('btnCentrar') || document.getElementById('filtroTipo')){
    const map = L.map('map').setView([-11.77,-75.33], 8);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{attribution:'© OpenStreetMap contributors'}).addTo(map);
    let markers = [];
    function render(tipoFiltro=''){
      markers.forEach(m=>map.removeLayer(m)); markers=[];
      const alerts = loadAlerts();
      const tipos = new Set();
      alerts.forEach(a=>{
        tipos.add(a.tipo);
        if(tipoFiltro && a.tipo!==tipoFiltro) return;
        if(!a.coords) return;
        const [lat,lng] = a.coords.split(',').map(Number);
        if(isNaN(lat)) return;
        const color = a.estado==='activa' ? '#dc2626' : '#16a34a';
        const icon = L.divIcon({html:'<div style="background:'+color+';color:white;padding:6px;border-radius:6px;font-weight:700">'+a.tipo[0]+'</div>', className:''});
        const m = L.marker([lat,lng], {icon}).addTo(map).bindPopup('<b>'+a.tipo+'</b><br>'+a.ubicacion);
        markers.push(m);
      });
      // fill filter
      const sel = document.getElementById('filtroTipo');
      if(sel){
        const prev = sel.value;
        sel.innerHTML = '<option value="">-- Todos --</option>';
        Array.from(tipos).forEach(t=>{ const o=document.createElement('option'); o.value=t; o.textContent=t; sel.appendChild(o); });
        sel.value = prev || '';
      }
    }
    render();
    document.getElementById('btnCentrar')?.addEventListener('click', ()=> {
      if(navigator.geolocation) navigator.geolocation.getCurrentPosition(p=> map.setView([p.coords.latitude, p.coords.longitude],13), ()=> alert('No se pudo localizar'));
    });
    document.getElementById('filtroTipo')?.addEventListener('change', e=> render(e.target.value));
  }

  // Historial
  if(document.getElementById('tablaAlertas')){
    function refreshTable(){
      const tbody = document.getElementById('tablaAlertas'); tbody.innerHTML = '';
      loadAlerts().slice().reverse().forEach(a=>{
        const tr = document.createElement('tr');
        tr.innerHTML = `<td>${new Date(a.fecha).toLocaleString()}</td><td>${a.tipo}</td><td>${a.ubicacion}</td><td>${a.estado}</td>
        <td><button onclick="confirmar('${a.id}')">Confirmar</button> <button onclick="cancelar('${a.id}')">Cancelar</button></td>`;
        tbody.appendChild(tr);
      });
    }
    window.confirmar = function(id){ const arr=loadAlerts(); const i=arr.findIndex(x=>x.id===id); if(i>-1){arr[i].estado='confirmada'; saveAlerts(arr); refreshTable();}}
    window.cancelar = function(id){ const arr=loadAlerts(); const i=arr.findIndex(x=>x.id===id); if(i>-1){arr[i].estado='cancelada'; saveAlerts(arr); refreshTable();}}
    refreshTable();
  }

  // Usuarios
  if(document.getElementById('btnAgregarUsuario')){
    function renderUsers(){ const ul=document.getElementById('listaUsuarios'); ul.innerHTML=''; loadUsers().forEach((u,idx)=>{ const li=document.createElement('li'); li.textContent = u.name + ' ('+u.role+') '; const b=document.createElement('button'); b.textContent='Eliminar'; b.addEventListener('click', ()=> { const arr=loadUsers(); arr.splice(idx,1); saveUsers(arr); renderUsers(); }); li.appendChild(b); ul.appendChild(li); }); }
    document.getElementById('btnAgregarUsuario').addEventListener('click', ()=>{
      const name = document.getElementById('nuevoUsuario').value.trim();
      const role = document.getElementById('rolUsuario').value;
      if(!name) return alert('Nombre requerido');
      const arr = loadUsers(); arr.push({name, role, created: nowISO()}); saveUsers(arr); renderUsers(); document.getElementById('nuevoUsuario').value='';
    });
    renderUsers();
  }

});
